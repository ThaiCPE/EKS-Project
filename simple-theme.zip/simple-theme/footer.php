<footer>
    <p>&copy; <?php echo date('Y'); ?> My Simple WordPress Theme</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
